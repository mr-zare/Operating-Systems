#include<stdio.h>
#include<string.h>
#include <sys/stat.h>
#include <sys/wait.h>
#include <stdlib.h>
#include <unistd.h>
#include <sys/types.h>

//code q3.1


void readfile(char *file[3])
{
    execvp(file[0] , file);
}
int main(int argc, char  *argv[])
{
    char* files1[3];
    files1[2] =NULL;
    files1[1] = argv[1];
    files1[0] = "cat";
  
   if((fork())==0){
       readfile(files1);
   }
   else
   {
   wait(NULL);
   }
   printf("%s" , "our file, write.\n");
    return 0;
}
