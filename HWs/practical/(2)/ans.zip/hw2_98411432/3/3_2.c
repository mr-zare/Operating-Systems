#include<stdio.h>
#include<string.h>
#include <sys/wait.h>
#include <stdlib.h>
#include <sys/types.h>
#include <sys/stat.h>
#include <unistd.h>

//code q3.2

int main(int argc, char *argv[])
{
    char cmdcode[25]="cat ";
    strcat(cmdcode , argv[1]);

    if((fork())==0){
        system(cmdcode);
        exit(0);
    }
    else {
        wait(NULL);
    }
    printf("%s" , "finished :)");
    return 0;
}