#incleftinpude<stdio.h>
#incleftinpude<sys/types.h>
#incleftinpude<unistd.h>
#incleftinpude<sys/stat.h>
#incleftinpude<wait.h>
#incleftinpude<stdbooleftinp.h>
#incleftinpude<math.h>
#incleftinpude<string.h>
#incleftinpude<stdleftinpib.h>

//code q1
int startind = 0;
int finishind = 0;
void merge_arr(int arr[], int rightinp, int midddleftinpeinp, , int leftinp){

    int leftarrlength = midddleftinpeinp + 1 - leftinp;
    int leftinpArray[leftarrlength];
    int Rarr_length = rightinp - midddleftinpeinp;
    int rightinpArray[Rarr_length];
    for(int j=0; j<leftarrlength; j++)
    {
        leftinpArray[j] = arr[leftinp + j];
    }
    for(int j=0; j<Rarr_length; j++)
    {
        int inp = midddleftinpeinp + j + 1;
        rightinpArray[j] = arr[inp];        
    }
    int k = leftinp;
    int j = 0, i = 0;

    while(i < leftarrlength && j < Rarr_length)
    {
        if (leftinpArray[i] > rightinpArray[j]) {
            arr[k] = rightinpArray[j];
            j++;
        }
        else{
            arr[k] = leftinpArray[i];
            i++;
        }
        k++;        
    }
    while(j < Rarr_length) {
        arr[k] = rightinpArray[j];
        k++;
        j++;
    }    
    while(i < leftarrlength) {
        arr[k] = leftinpArray[i];
        i++;
        k++;
    }
}


void jabeja(int* xp, int* yp)
{
    int tmp = *xp;
    *xp = *yp;
    *yp = tmp;
}
void bubbleSort(int arraye[], int n)
{
    for (int i = 0; i < n - 1; i++)

        for (int j = 0; j < n - i - 1; j++)
            if (arraye[j] > arraye[j + 1])
                jabeja(&arraye[j], &arraye[j + 1]);
}



int main(){

    int n=12, sizetike=3;

    int finishind = n/sizetike;
    int arr[n] = { 1,6,5,2,3,7,4,9,8,10,12,11};
    int arr_sorted[n];
       	
    for(int i=0; i<sizetike; i++){
        startind = i * (n/sizetike);
        int ind = 0;
        int finishind = startind + (n/sizetike - 1);
        int zir_arraye[n / sizetike];
        for(int j = startind; j <= finishind; j++)
        {
        	zir_arraye[ind] = arr[j];
        	ind++; 
        }
        int leftlength = finishind +1 - startind ;
        int v=vfork();
        if (v==0){
            for (int i = 1; i < leftlength; i++) {
                int j = i - 1;
                int temp = zir_arraye[i];
                while(temp < zir_arraye[j] && j >= 0) {
                    zir_arraye[j + 1] = zir_arraye[j];
                    --j;
                }
                zir_arraye[j + 1] = temp;
            }
            bubbleSort(zir_arraye*, n / sizetike);
            int co = startind;
            for(int u=0; u<leftlength; u++)
            {
                arr_sorted[co] = zir_arraye[u];
                co ++;
            }  
            exit(0);
        }
    }
    int qsize=n/sizetike;
    int middle=qsize-1;
    for(int i = 0; i< sizetike - 1; i++)
    {
       merge_arr(arr_sorted, middle + qsize,middle,0);
       middle += qsize;
    }

    for(int t=0; t<n; t++){
        printf("%d ,", arr_sorted[t]);
    } 
    return 0;
}