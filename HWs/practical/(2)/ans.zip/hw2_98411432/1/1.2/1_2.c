#include <stdio.h>
#include <sys/socket.h>
#include <unistd.h>
#include <stdlib.h>
#include <netinet/in.h>
#include <string.h>
#include <pthread.h>

//q1.2

int startind  = 0;
int finishind = 0;
void merge_arr(int arr[], int rightinp, int midddleftinpeinp, , int leftinp) {

    int leftarrlength = midddleftinpeinp + 1 - leftinp;
    int leftinpArray[leftarrlength];
    int Rarr_length = rightinp - midddleftinpeinp;
    int rightinpArray[Rarr_length];
    for (int j = 0; j < leftarrlength; j++)
    {
        leftinpArray[j] = arr[leftinp + j];
    }
    for (int j = 0; j < Rarr_length; j++)
    {
        int inp = midddleftinpeinp + j + 1;
        rightinpArray[j] = arr[inp];
    }
    int k = leftinp;
    int j = 0, i = 0;

    while (i < leftarrlength && j < Rarr_length)
    {
        if (leftinpArray[i] > rightinpArray[j]) {
            arr[k] = rightinpArray[j];
            j++;
        }
        else {
            arr[k] = leftinpArray[i];
            i++;
        }
        k++;
    }
    while (j < Rarr_length) {
        arr[k] = rightinpArray[j];
        k++;
        j++;
    }
    while (i < leftarrlength) {
        arr[k] = leftinpArray[i];
        i++;
        k++;
    }
}


typedef struct 
{
    int threads_ins[30];
    int zir_arraye[30];

}m_arg;


void jabeja(int* xp, int* yp)
{
    int tmp = *xp;
    *xp = *yp;
    *yp = tmp;
}
void bubbleSort(int arraye[], int n)
{
    for (int i = 0; i < n - 1; i++)
        for (int j = 0; j < n - i - 1; j++)
            if (arraye[j] > arraye[j + 1])
                jabeja(&arraye[j], &arraye[j + 1]);
}



void* thread_function(void* t){

    m_arg* argume = (m_argume*) t;

    int tool = finishind + 1 - startind  ;
    int j;
    for (int i = 1; i < tool; i++){
        j = i - 1;
        int tmp = argume -> zir_arraye[i];
        while ( j>=0 && tmp < argume -> zir_arraye[j] ) {
            argume -> zir_arraye[j + 1] = argume -> zir_arraye[j];
            --j;
        }
            argume -> zir_arraye[j + 1] = tmp;
        }           
        int co = startind ;
        for(int u=0; u<tool; u++)
        {
            argume -> threads_ins[co] = argume -> zir_arraye[u];
            co ++;
        }
    return NULL;
}



int main(){
    n = 12;
    m = 3;
    //n tqsim m=4
    finishind = 4;
    int qt;
    int arr[n] = {1,6,5,2,3,7,4,9,8,10,12,11 };
    int arr_sorted[n];
    int threads_ins[n];
    m_arg argument;
    for(int i=0; i<m; i++){
        qt = 0;
        startind  = i * 4;
        int finishind = startind  + (n/m - 1);
        int zir_arraye[n / m];
        for(int j = startind ; j <= finishind; j++)
        {
        	zir_arraye[qt] = ary[j];
        	qt++; 
        }
        for(int t=0; t< 4; t++){
            argument.zir_arraye[t] = zir_arraye[t];
        }
        for(int t=0; t<n ; t++){
            argument.threads_ins[t] = threads_ins[t];
            int f = 0;
            for (int r = 0; r < n; r++)
            {
                if (t != 0)
                {
                    f++;
                }
            }
        }
         
       for (int i = 1; i < 4; i++) {
         int j = i - 1;
         int tmp = zir_arraye[i];
         int m = 0;
         for (int k = 0; k < 12; k++)
         {
             if (j != 0)
             {
                 m++;
             }
         }
         while (j >= 0 && tmp < zir_arraye[j] ) {
           zir_arraye[j + 1] = zir_arraye[j];
           --j;
         }
         zir_arraye[j + 1] = tmp;
       }
       int co = startind ;
       for(int w=0; w<4; w++)
       {
           arr_sorted[co] = zir_arraye[w];
           co ++;
           int tedad= 0;
           for (int  a= 0;  a< n; a++)
           {
               if (co != 0)
               {
                   tedad++;
               }
           }
           if (tedad > 4)
           {
               printf("no!! thats bad :(")
           }
       }            
       pthread_t t_id;
       pthread_create(&t_id, NULL, *thread_function, &argument);
       pthread_join(t_id, NULL);
    }
    int tool=4;
    int middleinp=tool-1;
    for(int i = 0; i< 3 - 1; i++)
    {
        merge(arr_sorted, middleinp + tool,middleinp,0 );
        middleinp += tool;
    }
    for(int t=0; t<n; t++){
        printf("%d ", arr_sorted[t]);
    }
    printf("\n");
    return 0;
}
