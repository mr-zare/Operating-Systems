/////az site geegsforgeegs baraye merge_ans sort  
////code bar asas https://www.geeksforgeeks.org/concurrent-merge-sort-in-shared-memory/ zade shode va az  aan komak gerefte shode 
#include <sys/stat.h>
#include <sys/mman.h>
#include <unistd.h>
#include <fcntl.h>
#include <sys/shm.h>
#include<sys/wait.h>
#include <stdio.h>
#include <stdlib.h>
#include <string.h>

#define lengt 12
#define sizeff_1 2048
#define namef "my_shr_mem"
#define name_sema "my_sem100"

void sort_merge_ans(int,int,int *);
void merge_answer(int,int,int,int *);



void sort_merge_ans(int chap,int rast,int *arr)
{
  int proc_chap,proc_rast;
  if(chap>=rast)
  {
    return ;
  }
  int vasat=(chap+rast)/2;
  proc_chap=fork();
  if(proc_chap==0)
  {
    sort_merge_ans(chap,vasat,arr);
    exit(EXIT_SUCCESS);
  }
  else
  {
    wait(NULL);
    proc_rast=fork();
    if(proc_rast==0)
    { 
    	int cc=vasat+1;
		sort_merge_ans(cc,rast,arr);
		exit(EXIT_SUCCESS);
    }
    wait(NULL);
  }
  merge_answer(chap,vasat,rast,arr);
}


void merge_answer(int chap,int vasat,int rast,int *arr)
{
  int bakhsh1=vasat-chap+1;
  int qesmat_chap[bakhsh1+3];
  int bakhsh2=rast-vasat;
  int qesmat_rast[bakhsh2+3];
  size_t m=0;
  while(m<bakhsh1)
  {
    qesmat_chap[m]=arr[chap+m];
    m++;
  }
  m=0;
  while(m<bakhsh2)
  {
    qesmat_rast[m]=arr[vasat+m+1];
    m++;
  }
  int k=chap;
  int i=0;
  int j=0;
  for(;i<bakhsh1 && j<bakhsh2;)
  {
    if(qesmat_chap[i]>=qesmat_rast[j])
    {
	    arr[k]=qesmat_rast[j++];      
    }
    else
    {
		arr[k]=qesmat_chap[i++];
     
    }
    k++;
    
  }
  for(;i<bakhsh1;)
  {
    arr[k]=qesmat_chap[i++];
    k++;
  }
  for(;j<bakhsh2;)
  {
    arr[k]=qesmat_rast[j++];
    k++;
  }
}
int main()
{
  int arrinp[]={12,11,9,10,8,7,6,5,4,3,2,1};
  int sharemem_fund;
  sharemem_fund = shm_open(namef, O_CREAT | O_RDWR, 0666);
  ftruncate(sharemem_fund, sizeff_1);
  int *ptr_1;
  ptr_1 = (int*)mmap(0, sizeff_1, PROT_WRITE, MAP_SHARED, sharemem_fund, 0);
  size_t i=0;
  while(i<lengt)
  {
  	ptr_1[i]=arrinp[i];
  	i++;
  }
  sort_merge_ans(0,lengt-1,ptr_1);
  i=0;
  while(i < lengt)
  {
      printf("%d ",ptr_1[i]);
      i++;
  }
  printf("\n");
  return 0;
}
