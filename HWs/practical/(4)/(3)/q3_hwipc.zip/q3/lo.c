#include <unistd.h>
#include <stdlib.h>
#include <stdio.h>
#include <sys/wait.h>
#include <time.h>
#include <string.h>
#include <fcntl.h>

#define pipeline 2
#define number 50
#define SEM_NAME "semi3"
#define file_test "testfile.txt"

const char kalame[] = "MAMASTETODIVANEMARAKEBARADKHANEtohoshyarnemibinamharyekbadtarazdigarshooridevadivane";

char *reshtesshansi(int lengths) 
{
  srand(time(0));
  char *rand_str1 = malloc((lengths + 1) * sizeof(char));
  int i=0;
  while(i<lengths)
  {
	rand_str1[i] = kalame[rand()%strlen(kalame)];
	i++;
  }
  rand_str1[lengths] = '\0';
  return rand_str1;
}




int main(int argc, char const *argv[])
{
	int pipes_line1[pipeline];
    char char_read[50];
    int vazea;
    vazea=pipe(pipes_line1);
    int proc_id;
    int file_direc;
    char *reshte1=(char*)malloc(60*sizeof(char));
    char *reshte2=(char*)malloc(60*sizeof(char));
    file_direc=open(file_test,O_CREAT|O_WRONLY|O_TRUNC,S_IRWXU);
    proc_id=fork();
    if(proc_id!=0)
    {
		for (size_t i = 0; i < number; i++)   
		{
            int b=sizeof(reshte2);
            read(pipes_line1[0],reshte2,b);
            int a=strlen(reshte2);
            write(file_direc,reshte2,a);
            printf("resieved: %s\n", reshte2);
            printf("-------------------------\n");
            write(file_direc,"\n",1);
            sleep(2);
        }
    }
    else
    {
        for (size_t i = 0; i < number; i++)
        {
        	
        	sprintf(reshte1, "%ld:%s",i+1,reshtesshansi(4));
            printf("%s\n", reshte1);
            int c=sizeof(reshte1);
            write(pipes_line1[1],reshte1,c);
            sleep(2);
        }
    }
    close(file_direc);
    return 0;
}
