//
#include <stdio.h>
#include <stdlib.h>
#include <unistd.h>
#include <pthread.h>
#include <semaphore.h>

int present = 0;
sem_t wokeup_ti, sleep_tick;
void wakeme(int a)
{
    int notif;
    int away;
    away = present;
    while ((present - away) < a)
    {
        sem_wait(&wokeup_ti);
    }
    sem_post(&wokeup_ti);
}
void tick()
{
    present = present + 1;
    sem_post(&sleep_tick);
}

int main()
{
    sem_init(&wokeup_ti, 0, 1);
    sem_init(&sleep_tick, 0, 1);    
    sem_destroy(&wokeup_ti);
    sem_destroy(&sleep_tick);
    return 0;
}