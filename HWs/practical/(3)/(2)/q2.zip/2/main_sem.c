#include <stdio.h>
#include <semaphore.h>
#include <pthread.h>

sem_t lock[4];
sem_t lock_mohasebe_shomarande,lock_shomarande_updt;
double ans_matris[4];
double matris_a[4];
const int tedad_khoone=4;
const int tedad_thread = 4;
int mohasebe_shomarande=0;
double ans = 0;
int shomarande_updt=0;
int zarib_power=1;
const int power=150;

double khoone4()
{
    double javab;
    javab=ans_matris[3] * matris_a[3] + ans_matris[1] * matris_a[2];
    return javab;
}
double khoone2()
{
    double javab;
    javab=ans_matris[1] * matris_a[0] + ans_matris[3] * matris_a[1];
    return javab;
}
double khoone3()
{
    double javab;
    javab=ans_matris[0] * matris_a[2] + ans_matris[2] * matris_a[3];
    return javab;
}
double khoone1()
{
    double javab;
    javab=ans_matris[0] * matris_a[0] + ans_matris[2] * matris_a[1];
    return javab;
}

void *compute_ans(void *args)
{
    int type_thrd = *((pthread_t *)args);
    int i=2;
    while(power >= i)    
    {        
        double result;
        if(type_thrd+1 ==4)
        {
            result = khoone4();
        }
        if(type_thrd+1 ==2)
        {
           result = khoone2();

        }
        if(type_thrd+1 ==3)
        {
            result = khoone3();            
        }
        if(type_thrd+1 ==1)
        {
            result = khoone1();
        }
        sem_wait(lock+type_thrd);
        sem_wait(&lock_mohasebe_shomarande);
        mohasebe_shomarande=mohasebe_shomarande+1;
        sem_post(&lock_mohasebe_shomarande);
        sem_wait(lock+type_thrd);
        ans_matris[type_thrd]=result;
        sem_wait(&lock_shomarande_updt);
        shomarande_updt=shomarande_updt+1;
        sem_post(&lock_shomarande_updt);
        sem_wait(lock+type_thrd);
        sem_post(lock+type_thrd);
        i=i+1;
    }
}

void* mng_ans(void* args){
    while (power!=zarib_power)
    {
        while (tedad_khoone!=mohasebe_shomarande);
        int i=0;
        while(tedad_thread>i)
        {
            sem_post(lock+i);
            i++;
        }
        sem_wait(&lock_mohasebe_shomarande);
        mohasebe_shomarande=mohasebe_shomarande - tedad_khoone;
        sem_post(&lock_mohasebe_shomarande);
        while(tedad_khoone!=shomarande_updt);
        int j=0;
        while(j<tedad_thread)
        {
            sem_post(lock+j);
            j++;
        }
        sem_wait(&lock_shomarande_updt);
        shomarande_updt=shomarande_updt - tedad_khoone;
        sem_post(&lock_shomarande_updt);
        zarib_power++;
        printf("power %d:\n",zarib_power);
        int k=0;
        while(k<4)
        {
            printf("matrix[%d]:%lf\n",k,ans_matris[k]);
            k++;
        }
	}
}

int main()
{
    matris_a[0] = -1;
    matris_a[1] = 0;
    matris_a[2] = 0;
    matris_a[3] = 1;
    int i=0;
    while(tedad_khoone>i)
    {
        ans_matris[i] = matris_a[i];
        i++;
    }
    int j=0;
    while(j<tedad_khoone)
    {
        sem_init(lock+j, 0,1);
        j++;
    }
    sem_init(&lock_mohasebe_shomarande, 0,1);
    sem_init(&lock_shomarande_updt, 0,1);
    
    pthread_t idthrd[tedad_thread];
    int n_id[tedad_thread];
    pthread_t thread_id_manager;
    pthread_create(&thread_id_manager, NULL, *mng_ans, NULL);
    int k=0;
    while(k<tedad_thread)
    {
        n_id[k] = k;
        pthread_create(idthrd + k, NULL, *compute_ans, n_id + k);
        k++;
    }
    i=0;
    while(i<tedad_thread)
    {
        pthread_join(idthrd[i], NULL);
        i++;
    }
    pthread_join(thread_id_manager, NULL);
    i=0;
    while(i<tedad_khoone)
    {
        sem_destroy(lock+i);
        i++;
    }
    sem_destroy(&lock_mohasebe_shomarande);
    sem_destroy(&lock_shomarande_updt);
    return 0;
}