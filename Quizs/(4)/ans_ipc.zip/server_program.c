#include <stdio.h>
#include <semaphore.h>
#include <sys/mman.h>
#include <fcntl.h>
#include <string.h>
#include <unistd.h>
#include <stdlib.h>
#include <sys/types.h>
#include <sys/stat.h>

#define maximum_buff 10
#define sema_mut_name "/sem-mutex"
#define count_sema_buf_name "/sem-buffer-count"
#define sem_spl_sig_name "/sem-spool-signal"
#define sh_mem_name "/posix-shared-mem-example"
#define files_log "/tmp/example.log"


struct share_mem {
    int buff_ind;
    char buf [maximum_buff] [256];
    int print_buff_ind;
};

void error_log (char *massg);

int main (int argc, char **argv)
{
    char mybuf [256];
    int fdshm_, log_fd;
    sem_t *mtx_semaf, *bff_cnt_sema, *spl_sig_semaf;
    struct share_mem *shred_mem_ptr;
    if ((log_fd = open (files_log, O_CREAT | O_WRONLY | O_APPEND | O_SYNC, 0666)) == -1)
        error_log ("fopen");
    if ((mtx_semaf = sem_open (sema_mut_name, O_CREAT, 0660, 0)) == SEM_FAILED)
        error_log ("sem_open");
    if ((fdshm_ = shm_open (sh_mem_name, O_RDWR | O_CREAT | O_EXCL, 0660)) == -1)
        error_log ("shm_open");
    if (ftruncate (fdshm_, sizeof (struct share_mem)) == -1)
       error_log ("ftruncate");
    if ((shred_mem_ptr = mmap (NULL, sizeof (struct share_mem), PROT_READ | PROT_WRITE, MAP_SHARED,
            fdshm_, 0)) == MAP_FAILED)
       error_log ("mmap");
    shred_mem_ptr -> buff_ind = shred_mem_ptr -> print_buff_ind = 0;
    if ((bff_cnt_sema = sem_open (count_sema_buf_name, O_CREAT | O_EXCL, 0660, maximum_buff)) == SEM_FAILED)
        error_log ("sem_open");
    if ((spl_sig_semaf = sem_open (sem_spl_sig_name, O_CREAT | O_EXCL, 0660, 0)) == SEM_FAILED)
        error_log ("sem_open");
    if (sem_post (mtx_semaf) == -1)
        error_log ("sem_post: mtx_semaf");
    while (1) {  
        if (sem_wait (spl_sig_semaf) == -1)
            error_log ("sem_wait: spl_sig_semaf");    
        strcpy (mybuf, shred_mem_ptr -> buf [shred_mem_ptr -> print_buff_ind]);
        (shred_mem_ptr -> print_buff_ind)++;
        if (shred_mem_ptr -> print_buff_ind == maximum_buff)
           shred_mem_ptr -> print_buff_ind = 0;
        if (sem_post (bff_cnt_sema) == -1)
            error_log ("sem_post: bff_cnt_sema");
        if (write (log_fd, mybuf, strlen (mybuf)) != strlen (mybuf))
            error_log ("write: logfile");
    }
}
void error_log (char *massg)
{
    perror (massg);
    exit (1);
}