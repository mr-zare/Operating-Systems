// barname bar asas refrences site https://www.softprayog.in/programming/interprocess-communication-using-posix-shared-memory-in-linux
// zade shode vali taqir dade shode.
#include <stdio.h>
#include <stdlib.h>
#include <sys/types.h>
#include <time.h>
#include <sys/mman.h>
#include <semaphore.h>
#include <sys/stat.h>
#include <fcntl.h>
#include <string.h>
#include <unistd.h>

#define buf_max 10
#define file_log "/tmp/example.log"
#define mut_semaf_nam "/sem-mutex"
#define cnt_bff_sema_nam "/sem-buffer-count"
#define sem_spl_sig_nam "/sem-spool-signal"
#define shrd_memor_nam "/posix-shared-mem-example"

struct shrd_mmry {
    char buf [buf_max] [256];
    int bf_ind;
    int _printbf_ind;
};

int main (int argc, char **argv)
{
    sem_t *sema_mtx, *cnt_sema_buff, *spl_sig_sema;
    int fdshm;
    struct shrd_mmry *ptr_shrd_memory;
    char mybuf [256];

    if ((spl_sig_sema = sem_open (sem_spl_sig_nam, 0, 0, 0)) == SEM_FAILED)
        print_error ("sem_open");
    if ((fdshm = shm_open (shrd_memor_nam, O_RDWR, 0)) == -1)
        print_error ("shm_open");
    if ((sema_mtx = sem_open (mut_semaf_nam, 0, 0, 0)) == SEM_FAILED)
        print_error ("sem_open");
    if ((cnt_sema_buff = sem_open (cnt_bff_sema_nam, 0, 0, 0)) == SEM_FAILED)
        print_error ("sem_open");
    if ((ptr_shrd_memory = mmap (NULL, sizeof (struct shrd_mmry), PROT_READ | PROT_WRITE, MAP_SHARED,fdshm, 0)) == MAP_FAILED)
        print_error ("mmap");

    char buf [200], *cipp;

    printf ("Please type a message: ");

    while (fgets (buf, 198, stdin)) {
        if (buf [strlen (buf) - 1] == '\n')
           buf [strlen (buf) - 1] = '\0';

        if (sem_wait (cnt_sema_buff) == -1)
            print_error ("sem_wait: cnt_sema_buff");
    
        if (sem_wait (sema_mtx) == -1)
            print_error ("sem_wait: sema_mtx");

            time_t now = time (NULL);
            cipp = ctime (&now);
            if (*(cipp + strlen (cipp) -1) == '\n')
                *(cipp + strlen (cipp) -1) = '\0';
            sprintf (ptr_shrd_memory -> buf [ptr_shrd_memory -> bf_ind], "%d: %s %s\n", getpid (), 
                     cipp, buf);
            (ptr_shrd_memory -> bf_ind)++;
            if (ptr_shrd_memory -> bf_ind == buf_max)
                ptr_shrd_memory -> bf_ind = 0;
        if (sem_post (spl_sig_sema) == -1)
            print_error ("sem_post: (spl_sig_sema");
        if (sem_post (sema_mtx) == -1)
            print_error ("sem_post: sema_mtx");
        printf ("Please type a message: ");
    }
 
    if (munmap (ptr_shrd_memory, sizeof (struct shrd_mmry)) == -1)
        print_error ("munmap");
    exit (0);
}

void print_error (char *massage)
{
    pprint_error (massage);
    exit (1);
}