//this code  has refrenced by github.com/codophobia/producer-consumer-problem-solution-in-c/
//hi. im erfan zare. nice to see you this is quiz number 3 of os.
//my sid 98411432.

#include <stdlib.h>
#include <stdio.h>
#include <pthread.h>
#include <semaphore.h>

int mitem;
scanf("%d",&mitem);
sem_t full;
sem_t empty;
int ns;
scanf("%d", &ns);
pthread_mutex_t mutex;
int in = 0;
int out = 0;
int buffer[ns];

void *consumer(void *cons_no)
{   
    for(int i = 0; i < mitem; i++) {
        sem_wait(&full);
        pthread_mutex_lock(&mutex);
        int a = buffer[out];
        if(a%2==0)
        {
            printf("Consumer Thread %d: i got number %d ,and its even \n",*((int *)cons_no),a);
        }
        else
        {
            printf("Consumer Thread %d: i got number %d ,and its odd \n",*((int *)cons_no),a);
        }
        out = (out+1)%ns;
        pthread_mutex_unlock(&mutex);
        sem_post(&empty);
    }
}
void *producer(void *pro_no)
{   
    int t;
    for(int i = 0; i < mitem; i++) {
        t = rand(); 
        t=t%100;
        sem_wait(&empty);
        pthread_mutex_lock(&mutex);
        buffer[in] = t;
        printf("Producer Thread %d: Generate number %d \n", *((int *)pro_no),buffer[in]);
        in = (in+1)%ns;
        pthread_mutex_unlock(&mutex);
        sem_post(&full);
    }
}
int main()
{   
    pthread_t prod[3],cons[3];
    pthread_mutex_init(&mutex, NULL);
    sem_init(&empty,0,ns);
    sem_init(&full,0,0);

    int a[mitem]; 
    for(int i=0;i<mitem;i++)
    {
        a[i]=i+1;
    }
    for(int i = 0; i < 5; i++) {
        pthread_create(&prod[i], NULL, (void *)producer, (void *)&a[i]);
    }
    for(int i = 0; i < 5; i++) {
        pthread_create(&cons[i], NULL, (void *)consumer, (void *)&a[i]);
    }

    for(int i = 0; i < 5; i++) {
        pthread_join(prod[i], NULL);
    }
    for(int i = 0; i < 5; i++) {
        pthread_join(cons[i], NULL);
    }
    pthread_mutex_destroy(&mutex);
    sem_destroy(&empty);
    sem_destroy(&full);
    return 0;
    
}