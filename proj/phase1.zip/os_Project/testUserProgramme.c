#include "types.h"
#include "stat.h"
#include "user.h"





int main(int argc, char** argv) {



  int pid_process;
  int i;
  int blocker = 1;


  
  for (i = 0; i < 9; i++) {
    pid_process = fork();
    if (pid_process == 0) {
      blocker = 0;
      break;
    }
  }
  
  int Memory_Size[10] = {12356, 8452, 41389, 4895, 10020, 63200, 1850, 47820, 29870, 76800};  
  
  if (blocker) {
    struct proc_info* procs = malloc(sizeof(struct proc_info) * 64);
    sorted_process(procs);



    while (procs -> pid != -1 || procs -> memsize != -1) { 
      printf(2, "PID	:	%d 	memory occupied	:	%d\n", procs -> pid, procs -> memsize);
      printf(1,"_____________________________________________________________\n");
      procs++;
    }
    
    
    exit();
    
    
  } else { 
      int* a = malloc(sizeof(int) * Memory_Size[i]); 
      while(1) { a[0] = pid_process; int b = a[0] + pid_process; a[1] = b + a[0]; } 
      
      
  }
}